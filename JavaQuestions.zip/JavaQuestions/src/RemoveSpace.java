/* ABHIJIT RAY 849018 */
import java.util.Scanner;

public class RemoveSpace {

	public static void main(String[] args) {
		
		String s ;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter The String");
		s=sc.nextLine();
		String s1 =s.trim();
		System.out.println("Old:" + " " + s +"  ");
		
		System.out.println("New:" + " " + s1);
		
				
		

	}

}